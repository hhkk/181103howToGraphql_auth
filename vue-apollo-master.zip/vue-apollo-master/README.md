# hackernews-vue-apollo

> A VueJS project built with graphcool

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```
